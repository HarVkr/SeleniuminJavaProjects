package com.ok.javabrushup.oops;

public class Master {
    public static void main(String[] args) {
        Car car1 = new Car();
        car1.speed = 110;
        car1.color = "Black ";

        String op = car1.drive();
        System.out.println(op);

        Indians ind1 = new Indians();
        ind1.sayHello();
        ind1.sayBye();
        ind1.Sleep();

        Spanish sp = new Spanish();
        sp.Sleep();
    }
}
