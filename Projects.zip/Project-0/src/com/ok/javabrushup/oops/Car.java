package com.ok.javabrushup.oops;

public class Car {
    int speed;
    String color;

    String drive(){
        return "Driving";
    }
}




