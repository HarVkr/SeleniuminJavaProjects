package com.ok.javabrushup.oops;

abstract class People{
    abstract void sayHello();

    abstract void sayBye();

    void Sleep(){
        System.out.println("zzz....");
    }
}

class Indians extends People{
    @Override
    void sayHello(){
        System.out.println("Namaste");
    }
    @Override
    void sayBye(){
        System.out.println("aate hain");
    }

    @Override
    void Sleep() {
        super.Sleep();
    }
}

class Spanish extends People{
    @Override
    void sayHello(){
        System.out.println("hola");
    }
    @Override
    void sayBye(){
        System.out.println("adios");
    }

    @Override
    void Sleep() {
        super.Sleep();
    }
}

