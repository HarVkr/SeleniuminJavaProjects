package com.ok.javabrushup.datatypes;

public class Test {
    public static void main(String[] args) {
        System.out.println("Kaise ho?");

        // stored in string pool (heap memory)
        String str1 = "Hello";
        String str2 = "Hello";

        String str3 = new String("Hello");

        System.out.println(str1 == str2);
        System.out.println(str1 == str3);
        System.out.println(str1.equals(str3));

        int[] arr = new int[10];
        for(int i = 0; i < arr.length; i++){
            arr[i] = i;
        }
        int[] arr2 = new int[10];
        for(int num : arr2){
            System.out.println("second array num is: " + num);
        }
        for(int i = 0; i < arr2.length; i++){
            arr2[i] = arr[i];
        }
        for(int num : arr2){
            System.out.println("second array num is: " + num);
        }


    }
}
