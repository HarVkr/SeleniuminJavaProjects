package com.ok.javabrushup.collectionframework;

import java.util.ArrayList;
import java.util.List;

public class CF {
    public static void main(String[] args) {
        ArrayList<Integer> arrayList = new ArrayList<>();
        arrayList.add(1);

        List<Integer> list2 = new ArrayList();
        

    }
}
