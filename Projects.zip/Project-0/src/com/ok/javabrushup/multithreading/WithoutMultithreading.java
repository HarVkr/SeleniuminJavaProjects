package com.ok.javabrushup.multithreading;

public class WithoutMultithreading {
    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();

        long sum  = 0;
        for(int i = 1; i <= 1000000000; i++){
            sum += i;
        }
        System.out.println("Sum: " + sum);

        int count = 0;
        for (int i = 1; i <= 50000000; i++) {
            if(i % 10 == 7){
                count++;
            }
        }
        System.out.println("Count of numbers ending in 7: " + count);

        System.out.println("Time taken: " + (System.currentTimeMillis() - startTime));

    }

}
