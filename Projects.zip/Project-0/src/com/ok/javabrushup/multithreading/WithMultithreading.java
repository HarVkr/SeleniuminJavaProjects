package com.ok.javabrushup.multithreading;

public class WithMultithreading {
    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();

        NumberCounter thread1 = new NumberCounter();

        SumCalculator sumcal = new SumCalculator();
        Thread thread2 = new Thread(sumcal);

        thread1.start();
        thread2.start();


        try{
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }


        System.out.println("Time taken: " + (System.currentTimeMillis() - startTime));

    }
}
