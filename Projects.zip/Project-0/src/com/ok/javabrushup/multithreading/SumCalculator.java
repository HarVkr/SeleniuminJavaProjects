package com.ok.javabrushup.multithreading;

public class SumCalculator implements Runnable{
    @Override
    public void run() {
        long sum  = 0;
        for(int i = 1; i <= 1000000000; i++){
            sum += i;
        }
        System.out.println("Sum: " + sum);
    }
}
